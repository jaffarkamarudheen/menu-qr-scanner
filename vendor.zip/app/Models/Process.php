<?php

namespace App\Models;

class Process extends Posts
{
}
