<?php

namespace App\Models;

class Testimonials extends Posts
{
}
