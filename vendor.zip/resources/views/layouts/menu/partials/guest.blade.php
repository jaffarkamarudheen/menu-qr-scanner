<a href="/login?showCreate=true"  class="btn btn-neutral btn-icon web-menu">
    <span class="btn-inner--icon">
      <i class="fa fa-user mr-2"></i>
    </span>
    <span class="nav-link-inner--text">{{ __('Login') }}</span>
</a>
<a href="/login?showCreate=true"  class="nav-link nav-link-icon mobile-menu">
    <span class="btn-inner--icon">
      <i class="fa fa-user mr-2"></i>
    </span>
    <span class="nav-link-inner--text">{{ __('Login') }}</span>
</a>

