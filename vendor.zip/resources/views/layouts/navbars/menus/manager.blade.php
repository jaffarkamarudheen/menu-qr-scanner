<ul class="navbar-nav">
    <li class="nav-item">
        <a class="nav-link" href="{{ route('admin.restaurants.index') }}">
            <i class="ni ni-shop text-info"></i> {{ __('Restaurants') }}
        </a>
    </li>
        
</ul>
