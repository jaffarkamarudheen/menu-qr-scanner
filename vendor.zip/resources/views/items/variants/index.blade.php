@extends('general.index', $setup)
@include('items.variants.content')