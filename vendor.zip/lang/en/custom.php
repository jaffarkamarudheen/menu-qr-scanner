<?php

return [
    'customer_phone_number' => 'Customer phone number',
    'delivery_area_name' => 'Delivery area name',
    'client_phone' => 'Customer phone number',
    'client_name' => 'Client name',
];
